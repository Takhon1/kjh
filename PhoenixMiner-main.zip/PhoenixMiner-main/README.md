:warning: INSTRUÇÕES e INFORMAÇÕES

Este repositorio tem como finalidade facilitar o download do programa de mineração Phoenix Miner, sem nenhum objetivo de fins lucrativos. 
Todos direitos de criação pertecem a Phoenix Miner.

Link: https://phoenixminer.org/

Passo a passo para instalação após criar a VPS:

1 - Exetute o comando abaixo para atualizar o sistema
 
    sudo apt-get update
    
2 - Instale o gerenciador de repositorio Git e verifique se ele foi instalado corretamente utilizando os comandos abaixo:

    sudo apt-get install git
    git --version
    
3 - Instale a biblioteca libpci3 para o Phoenix Miner funcionar corretamente

    sudo apt-get install libpci3

4 - Clone o repositorio uilizando o comando do git:

    git clone https://github.com/L00K11/PhoenixMiner.git
    
5 - Utilize os comando abaixo para abrir as pastas:

    cd PhoenixMiner
    cd PhoenixMiner_L0K1
    
6 - Execute o comando abaixo para torna o Phoenix Miner executavel:

    chmod +x PhoenixMiner
    
7 - Configure a linha de comando abaixo para utilizar o algoritmo de mineração:

    ./PhoenixMiner -pool stratum+tcp://daggerhashimoto.eu.nicehash.com:3353 -wal sua_carteira -pass x -proto 4 -stales 0
    
    

*Ps: Script de inatinatividade para Google Colab:

    const main = async () => {
      try {
        document.querySelector("colab-run-button").click();
      }
      catch(err) {
        console.log('trabalhando...')
      }
    }
    setInterval(main,60000)
    
    


=========================================================================================




:warning: INSTRUCTIONS and INFORMATION

This repository is easy to download the Phoenix Miner mining program, not for profit purposes.
All creative rights belong to Phoenix Miner.

Link: https://phoenixminer.org/

Installation step after creating a VPS:

1 - Run the command below to update the system
 
    sudo apt-get update
    
2 - Install the Git repository manager and if it was installed correctly using the commands below:

    sudo apt-get install git
    git --version
    
3 - Install libpci3 library for Phoenix Miner to work correctly

    sudo apt-get install libpci3

4 - Clone the repository using the git command:

    git clone https://github.com/L00K11/PhoenixMiner.git
    
5 - Use the commands below to open as masses:

    cd PhoenixMiner
    cd PhoenixMiner_L0K1
    
6 - Run the command below to make Phoenix Miner executable:

    chmod +x PhoenixMiner
    
7 - Configure the command line below to use the mining algorithm:

    ./PhoenixMiner -pool stratum+tcp://daggerhashimoto.eu.nicehash.com:3353 -wal your_wallet -pass x -proto 4 -stales 0
    
    

*Ps: Downtime script for Google Colab:

    const main = async() => {
      try {
        document.querySelector("colab-run-button").click();
      }
      catch(err) {
        console.log('working...')
      }
    }
    setInterval(main,60000)


    
    
    
